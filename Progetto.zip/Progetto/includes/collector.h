#ifndef _COLLECTOR_H
#define _COLLECTOR_H

#include <utils.h>

void collector(long listen_fd);

#endif